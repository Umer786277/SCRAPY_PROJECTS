import scrapy

import  csv


class JeanspiderSpider(scrapy.Spider):
    name = "jeanspider"
    allowed_domains = ["88jeans.com"]
    start_urls = ["https://88jeans.com"]

    def parse(self, response):

        print(response.url)

        top_category_nodes=response.xpath("//ul[@id='main-nav']/li[a[not(contains(text(),'BRAND') or contains(text(),'SALE'))]]")

        for top_category_node in top_category_nodes:
            top_category_title=top_category_node.xpath("./a/text()").get().strip()
            print("TOP CATEGORY Title: ",top_category_title)
            category_nodes=response.xpath("//li[contains(@class,'megamenu__listcontainer')][h4/a[not(contains(text(),'BRAND'))]]")

            for category_node in category_nodes:
                category_title=category_node.xpath("./h4/a/text()").get()
                print("CATEGORY TITLE:",category_title)

                sub_category_nodes=response.xpath("//ul[contains(@class,'megamenu__list')]/li/a")

                for sub_category_node in sub_category_nodes:
                    sub_category_title=sub_category_node.xpath("./text()").get()
                    print("SUB CATEGORY TITLE: ",sub_category_title)
                    sub_category_url=sub_category_node.xpath("./@href").get()
                    breadcrumb = top_category_title + " " + category_title + " " + sub_category_title

                    yield scrapy.Request(response.urljoin(sub_category_url),callback=self.listing,meta={"breadcrumb":breadcrumb, "category_url":sub_category_url, "category":sub_category_title})


    def listing(self,response):

        print(response.url)

        products_nodes=response.xpath("//div[@class='product-info-inner']/a")

        for products_node in products_nodes:
            products_url=products_node.xpath("./@href").get()
            print("PRODUCTS URL",products_url)

            yield scrapy.Request(response.urljoin(products_url), callback=self.product_details, meta=response.meta)
            next_page_no = response.xpath("//div[@id='pagination']/a/text()").get()

            if next_page_no:
                next_page_url = f"{response.meta['category_url']}?page={next_page_no}"
                print("next_page_url", next_page_url)

    def product_details(self, response):
        product_url = response.url
        category = response.meta['breadcrumb']
        name = self.get_product_name(response)
        price = self.get_product_price(response)
        size = self.get_product_size(response)
        with open("jeans88.csv", "a+", encoding="UTF8", newline="") as f:
            writer = csv.writer(f)
            writer = writer.writerow([product_url, category, name, price, size])

    def get_product_name(self, reponse):
        return str(reponse.xpath("//div[@class='product__section-details']//h1/text()").get()).strip()

    def get_product_price(self, response):
        return response.xpath("//span[@class='price-item price-item--regular']/text()").get().strip()

    def get_product_size(self, response):
        return response.xpath("//div[contains(@class,'swatches__swatch--regular')]/label/text()").get().strip()



    #     print(response.url)
    #     print("____________________________________")
    #     """//ul[@id='main-nav']/li[a[not(contains(text(),'BRANDS')) and not(contains(text(),'SALE'))]]//li[h4[a[not(contains(text(),'BRAND'))]]]//li/a"""
    #     top_category_nodes = response.xpath(
    #         "//ul[@id='main-nav']/li[a[not(contains(text(),'BRAND') or contains(text(),'SALE'))]]")
    #     for top_category_node in top_category_nodes:
    #         top_category_title = top_category_node.xpath("./a/text()").get().strip()
    #         print("____________________________________")
    #         print("TOP CATEGORY TITLE", top_category_title)
    #         print("____________________________________")
    #         category_nodes = top_category_node.xpath(".//li[contains(@class,'megamenu__listcontainer')][h4/a[not(contains(text(),'BRAND'))]]")
    #         for category_node in category_nodes:
    #             category_title = category_node.xpath("./h4/a/text()").get()
    #             print("CATEGORY TITLE", category_title)
    #             sub_category_nodes = category_node.xpath(".//ul[contains(@class,'megamenu__list')]/li/a")
    #             for sub_category_node in sub_category_nodes:
    #                 sub_category_title = sub_category_node.xpath("./text()").get()
    #                 print("SUB CATEGORY TITLE", sub_category_title)
    #                 sub_category_url = sub_category_node.xpath("./@href").get()
    #
    #                 breadcrumb = top_category_title + " " + category_title + " " + sub_category_title
    #                 yield scrapy.Request(response.urljoin(sub_category_url), callback=self.listing,
    #                                       meta={"breadcrumb": breadcrumb, "category_url": sub_category_url,
    #                                             "category": sub_category_title})
    #
    #
    # def listing(self,response):
    #     print(response.url)
    #     product_nodes=response.xpath("//div[@class='product-info-inner']/a")
    #
    #     for product_node in product_nodes:
    #         product_url=product_node.xpath("./@href").get()
    #         print("Product Url",product_url)
    #
    #



