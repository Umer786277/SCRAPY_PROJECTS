import json
import csv

import scrapy
from copy import deepcopy
from urllib.parse import urljoin
class SpaperoSpider(scrapy.Spider):
    name = "spapero"
    allowed_domains = ["www.aperolabel.com"]
    start_urls = ["https://www.aperolabel.com"]

    def parse(self, response):

        top_category_nodes=response.xpath("//div[@id='main-nav']/div/div/ul/li[a[contains(text(),'SHOP')]]")
        for top_category_node in top_category_nodes:
            top_category_title=top_category_node.xpath("./a/text()").get().strip()
            print("Top Category Title: ",top_category_title)

            category_nodes=top_category_node.xpath(".//div[@id='NavigationTier2-2']/div/ul/li[a[not(contains(@href,'#') or contains(text(),'ALL'))]]")

            for category_node in category_nodes:
                category_title= category_node.xpath("./a/text()").get().strip()
                print("Category Title: ",category_title)

                sub_category_nodes=category_node.xpath("./div[contains(@class,'navigation__tier-3-container')]/ul/li/a")
                for sub_category_node in sub_category_nodes:

                    sub_category_title=sub_category_node.xpath("./text()").get()
                    print("Sub Category Title: ",sub_category_title)

                    sub_category_url=sub_category_node.xpath("./@href").get()

                    breadcrumb=top_category_title+ "" + category_title + "" + sub_category_title + ""

                    yield scrapy.Request(response.urljoin(sub_category_url),callback=self.listing,
                                         meta={"breadcrumb": breadcrumb, "category_url": sub_category_url,
                                                "category": sub_category_title})


    def listing(self,response):

        collection_handle = response.url.split('/')[-1]

        api_url = f"https://50mkzg.a.searchspring.io/api/search/search.json?domain={response.url}&siteId=50mkzg&page=1&bgfilter.collection_handle={collection_handle}&ajaxCatalog=Snap&resultsFormat=native"

        yield scrapy.Request(url=api_url, callback=self.parse_pagination, meta={'resp':response.meta,'list_url':response.url}, dont_filter=True)
    def parse_pagination(self,response):
        json_load=json.loads(response.text)
        total_page=int(json_load['pagination']['totalPages'])
        print("Total Pages  ",total_page)

        for page in range(1,total_page+1):
            copy_url=deepcopy(response.url)
            next_page_url = copy_url.split('page=1')[0] + f'page={page}' + copy_url.split('page=1')[-1]
            print("Next Page Url: ",next_page_url)

            yield scrapy.Request(url=next_page_url,callback=self.parse_listing,meta=response.meta,dont_filter=True)

    def parse_listing(self,response):


        api_response = json.loads(response.text)


        for pro_token in api_response['results']:
            cat_url=response.meta['list_url']
            print('----------',cat_url)
            product_url = pro_token['url']
            print("Product Url: ", product_url)
            breadcrumb = response.meta.get('breadcrumb','')
            meta = {'breadcrumb': breadcrumb}
            url=f"https://www.aperolabel.com/{product_url}.js"
            yield scrapy.Request(url=url, callback=self.prod_det,  meta=meta, dont_filter=True)

    def prod_det(self,response):

        product_url = response.url
        print("Product Url api ",response.url)
        category = response.meta['breadcrumb']
        name = self.get_product_name(response)
        price = self.get_product_price(response)
        with open("aperojeans.csv", "a+", encoding="UTF8", newline="") as f:
            writer = csv.writer(f)
            writer = writer.writerow([category, name, price,product_url])



    def get_product_name(self, response):
        ap_response = json.loads(response.text)
        title = ap_response['title']
        print("Product Name: ", title)
        return str(title)

    def get_product_price(self, response):
        ap_response = json.loads(response.text)
        price = ap_response['price']
        print("Product Price: ", price)
        return str(price)


        # breadcrumb = response.meta
    #     product_url = response.url
    #     category = response.meta['breadcrumb']
    #     name = self.get_product_name(response)
    #     price = self.get_product_price(response)
    #     with open("aperojeans.csv", "a+", encoding="UTF8", newline="") as f:
    #         writer = csv.writer(f)
    #         writer = writer.writerow([breadcrumb,product_url, category, name, price])
    #
    # def get_product_name(self, response):
    #     api_response = json.loads(response.text)
    #     for token in api_response['results']:
    #         prod_name = token['name']
    #         print("Product Name: ", prod_name)
    #         return str(prod_name)
    #
    # def get_product_price(self, response):
    #     api_response = json.loads(response.text)
    #     for token in api_response['results']:
    #         prod_price = token['price']
    #         print("Product Price: ", prod_price)
    #         return str(prod_price)
        # api_response=json.loads(response.text)
        # for token in api_response ['results']:
        #     prod_price=token['name']
        #     print("Product Name: ",prod_name)
        # for token in api_response ['results']:
        #     prod_price=token['price']
        #     print("Product Price: ",prod_price)
        #
        #     with open("apperojeans.csv", "a+", encoding="UTF8", newline="") as f:
        #     writer = csv.writer(f)
        #     writer = writer.writerow([breadcrumb,prod_name,prod_price])







# ap_response=json.loads(response.text)
        # title=ap_response['title']
        # print("Product Name: ", title)
        # price=ap_response['price']
        # print("Product Price: ",price)




