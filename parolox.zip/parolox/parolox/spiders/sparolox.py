import scrapy
from urllib.parse import urljoin
import csv


class SparoloxSpider(scrapy.Spider):
    name = "sparolox"
    allowed_domains = ["parlourx.com"]
    start_urls = ["https://parlourx.com"]

    def parse(self, response):

        category_nodes=response.xpath("//nav[@class='header__menu']/div/div[a/span[not(contains(text(),'About') or contains(text(),'Designers'))]]")
        for category_node in category_nodes:
            category_title=category_node.xpath("./a/span/text()").get()
            print("Category Title: ",category_title)

            sub_category_nnodes=category_node.xpath(".//div[@class='header__dropdown']/div/div/div/div/a[span]")
            if sub_category_nnodes:
                for sub_category_node in sub_category_nnodes:
                    sub_category_title=sub_category_node.xpath("./span/text()").get()
                    print("Sub Category Title: ",sub_category_title)
                    breadcrumb=category_title+ "" + sub_category_title
                    url = sub_category_node.xpath("./@href").get()
                    print("************",url)
                    yield scrapy.Request(url=urljoin(response.url,url),callback=self.listing,
                    meta={'breadcrumb':breadcrumb,'url':url})
            else:
                url =category_node.xpath("./a/@href").get()
                breadcrumb = category_title
                yield scrapy.Request(url=urljoin(response.url,url), callback=self.listing,
                meta={'breadcrumb':breadcrumb,'url':url})



    def listing(self,response):
        products_nodes=response.xpath("//div[@class='product-information']/a")
        for products_node in products_nodes:
            product_url=products_node.xpath("./@href").get()
            print("Product Url: ",product_url)
            yield scrapy.Request(url=urljoin(response.url,product_url), callback=self.prod_details,meta=response.meta)
            next_page_no = response.xpath("//link[@rel='next']").get()

            if next_page_no:
                next_page_url = f"{response.meta['url']}?page={next_page_no}"
                print("next_page_url", next_page_url)
                yield scrapy.Request(url=urljoin(response.url, next_page_url), callback=self.listing,
                                     meta=response.meta)


    def prod_details(self,response):
        produuct_url=response.url
        category = response.meta['breadcrumb']
        colour = self.get_product_colour(response)
        price = self.get_product_price(response)
        size = self.get_product_size(response)
        with open("apoorolox.csv", "a+", encoding="UTF8", newline="") as f:
            writer = csv.writer(f)
            writer = writer.writerow([produuct_url, category, colour, price, size])


    def get_product_colour(self,response):
        return str(response.xpath("normalize-space(//fieldset/div[legend/span/span[contains(text(),'COLOUR')]]/""div/span/label/span/text())").get())


    def get_product_price(self,response):
        return str(response.xpath("//div[@class='product__price']/span/span/text()").get()).strip()

    def get_product_size(self,response):
        return str(response.xpath("normalize-space(//fieldset/div[legend/span/span[contains(text(),'Size')]]/""div/span/label/span/text())").get())



